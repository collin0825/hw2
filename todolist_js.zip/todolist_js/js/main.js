let addTodoElement = () => {
    let todoForm = document.querySelector(".todo-form");
    let todoInput = document.querySelector(".todo-form input[type='text']");
    let todoListArea = document.querySelector(".todo-list");
    let listTemplate = document.querySelector("template");
    let finishedArea = document.querySelector(".finished-list");
    let allArea =document.querySelector(".all-list");
    let tab = document.querySelector(".tab");
    let all = document.querySelector(".all");
    let working = document.querySelector(".working");
    let finished = document.querySelector(".finished");
    let clearAll = document.querySelector(".clear-all-button");
    element = {
        todoForm,
        todoInput,
        todoListArea,
        listTemplate,
        finishedArea,
        allArea,
        tab,
        all,
        working,
        finished,
        clearAll
    }
    return element
}

let eventlist = [];
addTodo()
function addTodo(){
    // 將input 的內容指派至template中的li裡面的p，然後讓他出現在放置任務的區域。
    let renderTemplate = (eventlist, todolist, alllist)=>{
        if(eventlist.length>1){
            for(let i = 0; i<eventlist.length-1; i++){
                todolist.removeChild(todolist.lastElementChild);
                alllist.removeChild(alllist.lastElementChild);
            }
        }
        eventlist.forEach(element => {
            if(element.completed === false){
                let clone = document.importNode(addTodoElement().listTemplate.content,true)
                let value = element.text
                clone.querySelector(".task .content").textContent = value;
                todolist.appendChild(clone);
            }
            let clone = document.importNode(addTodoElement().listTemplate.content,true)
            let value = element.text
            clone.querySelector(".task .content").textContent = value;
            alllist.appendChild(clone);
        });
        
    }
// 監聽form的submit事件
    addTodoElement().todoForm.addEventListener("submit",(e)=>{
        e.preventDefault();
        document.querySelector(".no-new-task").style.display = "none" ;
        document.querySelector(".no-task").style.display = "none" ;
        let content = addTodoElement().todoInput.value;
        let event={
            completed: false,
            text: content
        }
        eventlist.push(event);
        renderTemplate(eventlist, addTodoElement().todoListArea, addTodoElement().allArea);
        addTodoElement().todoForm.reset()
    })
}
function reFresh(){
    let alllen = addTodoElement().allArea.childElementCount;
    let todolen = addTodoElement().todoListArea.childElementCount;
    let finishedlen = addTodoElement().finishedArea.childElementCount;
    for(let i = 0; i < alllen-1; i++){
        addTodoElement().allArea.removeChild(addTodoElement().allArea.lastElementChild);
    }
    for(let j = 0; j < todolen-1; j++){
        addTodoElement().todoListArea.removeChild(addTodoElement().todoListArea.lastElementChild);
    }
    for(let k = 0; k < finishedlen-1; k++){
        addTodoElement().finishedArea.removeChild(addTodoElement().finishedArea.lastElementChild);
    }
    eventlist.forEach(element => {
        if(element.completed === false){
            let clone = document.importNode(addTodoElement().listTemplate.content,true)
            let value = element.text
            clone.querySelector(".task .content").textContent = value;
            addTodoElement().todoListArea.appendChild(clone);
            let clone1 = document.importNode(addTodoElement().listTemplate.content,true)
            let value1 = element.text
            clone1.querySelector(".task .content").textContent = value1;
            addTodoElement().allArea.appendChild(clone1);
        }
        if(element.completed === true){
            let clone = document.importNode(addTodoElement().listTemplate.content,true)
            let value = element.text
            clone.querySelector(".task .content").textContent = value;
            clone.querySelector(".task .check").checked = true;
            clone.querySelector(".task").style.textDecoration = "line-through black";
            addTodoElement().finishedArea.appendChild(clone);
            let clone1 = document.importNode(addTodoElement().listTemplate.content,true)
            let value1 = element.text
            clone1.querySelector(".task .content").textContent = value1;
            clone1.querySelector(".task .check").checked = true;
            clone1.querySelector(".task").style.textDecoration = "line-through black";
            addTodoElement().allArea.appendChild(clone1);

        }
    });
    setTimeout(()=>{
        if(document.querySelectorAll(".all-list .task").length === 0){
            document.querySelector(".no-task").style.display = "block"
        }
        else if(document.querySelectorAll(".all-list .task").length !== 0){
            document.querySelector(".no-task").style.display = "none"
        }
    },10)
    setTimeout(()=>{
        if(document.querySelectorAll(".todo-list .task").length === 0){
            document.querySelector(".no-new-task").style.display = "block"
        }
        else if(document.querySelectorAll(".todo-list .task").length !== 0){
            document.querySelector(".no-new-task").style.display = "none"
        }
    },10)
    setTimeout(()=>{
        if(document.querySelectorAll(".finished-list .task").length === 0){
            document.querySelector(".no-finished-task").style.display = "block"
        }
        else if(document.querySelectorAll(".finished-list .task").length !== 0){
            document.querySelector(".no-finished-task").style.display = "none"
        }
    },10)
}

// todolist刪除及畫線
addTodoElement().todoListArea.addEventListener("click",(e)=>{
    // 判斷點擊的對象是不是刪除，是的話就將任務刪除。
    if(e.target.classList[1] === "fa-trash-alt"){
        let event = e.target.parentNode.previousElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist.splice(i, 1);
            }
        });
        reFresh();
    }
    if(e.target.classList[0] === "check" && e.target.checked){
        let event = e.target.nextElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist[i].completed = true;
            }
        });
        reFresh();
    }
})

// Alllist刪除及畫線
addTodoElement().allArea.addEventListener("click",(e)=>{
    // 判斷點擊的對象是不是刪除，是的話就將任務刪除。
    if(e.target.classList[1] === "fa-trash-alt"){
        let event = e.target.parentNode.previousElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist.splice(i, 1);
            }
        });
        reFresh();
    }
    if(e.target.classList[0] === "check" && e.target.checked){
        let event = e.target.nextElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist[i].completed = true;
            }
        });
        reFresh();
    }
    if(e.target.classList[0] === "check" && !e.target.checked){
        let event = e.target.nextElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist[i].completed = false;
            }
        });
        reFresh();
    }
})

addTodoElement().finishedArea.addEventListener("click",(e)=>{
    // 判斷點擊的對象是不是刪除，是的話就將任務刪除。
    if(e.target.classList[1] === "fa-trash-alt"){
        let event = e.target.parentNode.previousElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist.splice(i, 1);
            }
        });
        reFresh();
    }
    if(e.target.classList[0] === "check" && !e.target.checked){
        let event = e.target.nextElementSibling.innerHTML;
        let i;
        eventlist.forEach(element => {
            if(element.text === event){
                i = eventlist.indexOf(element);
                eventlist[i].completed = false;
            }
        });
        reFresh();
    }
})

// tag切換
addTodoElement().tab.addEventListener("click",(e)=>{
    switch (e.target.classList[0]) {
        case "all":
            e.target.classList.add("active")
            addTodoElement().working.classList.remove("active")
            addTodoElement().finished.classList.remove("active")
            addTodoElement().allArea.classList.add("active")
            addTodoElement().todoListArea.classList.remove("active")
            addTodoElement().finishedArea.classList.remove("active")
            break;
        case "working":
            e.target.classList.add("active")
            addTodoElement().all.classList.remove("active")
            addTodoElement().finished.classList.remove("active")
            addTodoElement().todoListArea.classList.add("active")
            addTodoElement().allArea.classList.remove("active")
            addTodoElement().finishedArea.classList.remove("active")
            break;
        case "finished":
            e.target.classList.add("active")
            addTodoElement().working.classList.remove("active")
            addTodoElement().all.classList.remove("active")
            addTodoElement().finishedArea.classList.add("active")
            addTodoElement().allArea.classList.remove("active")
            addTodoElement().todoListArea.classList.remove("active")
            break;
    }
})

// ClearAll
addTodoElement().clearAll.addEventListener("click",(e)=>{
    eventlist = [];
    reFresh();
    alert("任務已全部清除!!")
})