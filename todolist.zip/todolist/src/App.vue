<template>
  <div class="todolist-section">
    <div class="todo-container">
        <div class="todo-header">
          <h1>My To-do List</h1>
        </div>
        <div class="todo-input-area">
          <form action="" class="todo-form">
            <input type="text" placeholder="在此輸入........" v-model="newInput" @keyup.enter="addItem()">
            <input type="submit" value="新增任務" @click="addItem()">
          </form>
        </div>
        <div class="task-list-area">
          <div class = "tab">
            <div v-for="(item, index) in tabs" @click="tabIndex = index" :key = "item.Name" :class ="[{'active': tabIndex===index}, item.TabName, 'tab-item']">
              {{item.Name}}
            </div>
          </div>
          <ul class="todolist">
            <h3 class="no-task" v-if=" filterList.length=== 0">目前無資料</h3>
            <li class = "task" v-for="item in filterList" :key="item.id">
                <input type="checkbox" class="check item" :id="item.id" v-model="item.done">
                <label :for="item.id" :class="[{'line-through':item.done}, 'content item']">{{item.content}}</label>
                <span class="delete item" @click="deleteItem(item)"><i class="far fa-trash-alt"></i></span>
            </li>
          </ul>
        </div>
        <div class="clear-all">
          <button class = "clear-all-button" @click="deleteAll()">全部清除</button>
        </div>
    </div>
  </div>
</template>

<style lang="scss">
@import "assets/all.scss";
</style>
<script>
export default {
  data () {
    return {
      tabs: [
        {
          Name: '全部',
          TabName: 'all'
        },
        {
          Name: '進行中',
          TabName: 'working'
        },
        {
          Name: '已完成',
          TabName: 'finished'
        }
      ],
      tabIndex: 0,
      list: [],
      newInput: ''
    }
  },
  methods: {
    addItem () {
      if (this.newInput.trim()) {
        this.list.push({
          id: Math.floor(Date.now()),
          content: this.newInput,
          done: false
        })
        this.newInput = ''
      }
    },
    deleteItem (target) {
      this.list.forEach((item, index) => {
        if (item.id === target.id) {
          this.list.splice(index, 1)
        }
      })
    },
    deleteAll () {
      alert('資料已全部清除!!!')
      this.list = []
    }
  },
  computed: {
    filterList () {
      const newList = []
      if (this.tabs[this.tabIndex].TabName === 'all') {
        this.list.forEach(item => {
          newList.push(item)
        })
      } else if (this.tabs[this.tabIndex].TabName === 'working') {
        this.list.forEach(item => {
          if (item.done === false) {
            newList.push(item)
          }
        })
      } else if (this.tabs[this.tabIndex].TabName === 'finished') {
        this.list.forEach(item => {
          if (item.done === true) {
            newList.push(item)
          }
        })
      }
      return newList
    }
  }
}
</script>
